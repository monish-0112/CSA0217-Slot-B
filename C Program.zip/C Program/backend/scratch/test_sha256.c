#include <stdio.h>
#include "../src/sha256.h"

int main(void) {
    char hash[65];
    sha256_hash("admin123", hash);
    printf("Hash: %s\n", hash);
    return 0;
}
