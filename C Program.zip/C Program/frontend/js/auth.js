function renderLoginPage() {
  const app = document.getElementById('app');
  app.innerHTML = `
    <div class="full-screen-center">
      <div class="card auth-card">
        <div style="text-align: center; margin-bottom: 1.5rem;">
          <span style="font-size: 0.75rem; letter-spacing: 0.15em; text-transform: uppercase; color: var(--primary); font-weight: 700; background: rgba(99, 102, 241, 0.15); padding: 4px 12px; border-radius: 20px; border: 1px solid rgba(99, 102, 241, 0.3); display: inline-block; margin-bottom: 0.5rem;">SIMATS ENGINEERING</span>
          <h2 style="margin: 0; font-size: 1.7rem;">HostelHub Portal 🏠</h2>
        </div>
        
        <div class="tabs">
          <div class="tab active" id="tab-student" onclick="switchLoginTab('student')">Student</div>
          <div class="tab" id="tab-admin" onclick="switchLoginTab('admin')">Admin</div>
        </div>

        <form id="login-form" onsubmit="handleLogin(event)">
          <div class="form-group">
            <label id="login-label">Email Address</label>
            <input type="text" id="email" class="input" required placeholder="student@example.com" autocomplete="username">
          </div>
          
          <div id="admin-notice" class="hidden">
            <p style="font-size: 0.8rem; color: var(--primary); background: rgba(99,102,241,0.1); padding: 6px 12px; border-radius: 6px; margin-bottom: 1rem;">
              🔑 <strong>Default Admin Credentials:</strong><br>
              Username: <code style="color:var(--text-primary)">admin</code> | Password: <code style="color:var(--text-primary)">admin123</code>
            </p>
          </div>
          
          <div class="form-group">
            <label>Password</label>
            <input type="password" id="password" class="input" required placeholder="••••••••" autocomplete="current-password">
          </div>
          
          <button type="submit" class="btn btn-primary" style="width: 100%; margin-top: 1rem;">Login 🔑</button>
        </form>
        
        <p class="text-center mt-3 text-secondary" style="font-size: 0.9rem;" id="register-link-container">
          Don't have an account? <a href="#/register">Register here</a>
        </p>
      </div>
    </div>
  `;
}

function switchLoginTab(role) {
  document.getElementById('tab-student').classList.remove('active');
  document.getElementById('tab-admin').classList.remove('active');
  document.getElementById('tab-' + role).classList.add('active');
  
  const loginLabel = document.getElementById('login-label');
  const emailInput = document.getElementById('email');
  const adminNotice = document.getElementById('admin-notice');
  const regContainer = document.getElementById('register-link-container');

  if (role === 'student') {
    if (loginLabel) loginLabel.textContent = 'Email Address';
    if (emailInput) emailInput.placeholder = 'student@example.com';
    if (adminNotice) adminNotice.classList.add('hidden');
    if (regContainer) regContainer.classList.remove('hidden');
  } else {
    if (loginLabel) loginLabel.textContent = 'Username';
    if (emailInput) emailInput.placeholder = 'admin';
    if (adminNotice) adminNotice.classList.remove('hidden');
    if (regContainer) regContainer.classList.add('hidden');
  }
}

async function handleLogin(e) {
  e.preventDefault();
  const isStudentTab = document.getElementById('tab-student').classList.contains('active');
  const inputVal = (document.getElementById('email').value || '').trim();
  const password = (document.getElementById('password').value || '').trim();
  
  if (!inputVal || !password) {
    showToast('Please enter both username/email and password', 'error');
    return;
  }

  try {
    if (!isStudentTab || inputVal.toLowerCase() === 'admin') {
      const res = await apiPost('/api/admin/login', { username: inputVal || 'admin', password });
      setToken(res.token);
      setUser(res.user);
      setRole('admin');
      showToast('Logged in as Admin 🔑', 'success');
      window.location.hash = '#/admin/dashboard';
      router();
    } else {
      const res = await apiPost('/api/student/login', { email: inputVal, password });
      setToken(res.token);
      setUser(res.user);
      setRole('student');
      showToast('Logged in successfully', 'success');
      window.location.hash = '#/student/dashboard';
      router();
    }
  } catch (err) {
    showToast(err.message, 'error');
  }
}

function renderRegisterPage() {
  const app = document.getElementById('app');
  app.innerHTML = `
    <div class="full-screen-center" style="padding: 2rem 1rem;">
      <div class="card auth-card" style="max-width: 500px;">
        <h2 class="text-center mb-4">Student Registration 📝</h2>
        
        <form id="register-form" onsubmit="handleRegister(event)">
          <div class="grid-2">
            <div class="form-group">
              <label>Full Name</label>
              <input type="text" id="reg-name" class="input" required>
            </div>
            <div class="form-group">
              <label>Student ID</label>
              <input type="text" id="reg-id" class="input" required>
            </div>
          </div>
          
          <div class="form-group">
            <label>Email</label>
            <input type="email" id="reg-email" class="input" required>
          </div>
          
          <div class="grid-2">
            <div class="form-group">
              <label>Department</label>
              <select id="reg-dept" class="input" required>
                <option value="">Select Dept</option>
                <option value="Computer Science">Computer Science</option>
                <option value="Electronics">Electronics</option>
                <option value="Mechanical">Mechanical</option>
                <option value="Civil">Civil</option>
                <option value="Chemical">Chemical</option>
                <option value="Other">Other</option>
              </select>
            </div>
            <div class="form-group">
              <label>Year</label>
              <select id="reg-year" class="input" required>
                <option value="">Select Year</option>
                <option value="1">1st Year</option>
                <option value="2">2nd Year</option>
                <option value="3">3rd Year</option>
                <option value="4">4th Year</option>
              </select>
            </div>
          </div>
          
          <div class="form-group">
            <label>Phone Number</label>
            <input type="tel" id="reg-phone" class="input" required>
          </div>

          <div class="grid-2">
            <div class="form-group">
              <label>Password</label>
              <input type="password" id="reg-pass" class="input" required minlength="6">
            </div>
            <div class="form-group">
              <label>Confirm Password</label>
              <input type="password" id="reg-pass2" class="input" required minlength="6">
            </div>
          </div>
          
          <button type="submit" class="btn btn-primary" style="width: 100%; margin-top: 1rem;">Register ✅</button>
        </form>
        
        <p class="text-center mt-3 text-secondary" style="font-size: 0.9rem;">
          Already have an account? <a href="#/login">Login here</a>
        </p>
      </div>
    </div>
  `;
}

async function handleRegister(e) {
  e.preventDefault();
  const pass1 = document.getElementById('reg-pass').value;
  const pass2 = document.getElementById('reg-pass2').value;
  
  if (pass1 !== pass2) {
    showToast('Passwords do not match', 'error');
    return;
  }
  
  const body = {
    name: document.getElementById('reg-name').value,
    email: document.getElementById('reg-email').value,
    password: pass1,
    student_id: document.getElementById('reg-id').value,
    department: document.getElementById('reg-dept').value,
    year: parseInt(document.getElementById('reg-year').value),
    phone: document.getElementById('reg-phone').value
  };
  
  try {
    await apiPost('/api/student/register', body);
    showToast('Registration successful! Please login.', 'success');
    window.location.hash = '#/login';
  } catch (err) {
    showToast(err.message, 'error');
  }
}
