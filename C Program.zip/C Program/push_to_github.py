import os
import sys
import json
import base64
import urllib.request
import urllib.error

REPO_OWNER = "rajmuruga-0306"
REPO_NAME = "c-programming"
PROJECT_DIR = os.path.dirname(os.path.abspath(__file__))

def get_all_files(root_dir):
    ignore_dirs = {'.git', '__pycache__', 'node_modules', '.gemini', 'scratch'}
    ignore_files = {'push_to_github.py'}
    file_paths = []
    for dirpath, dirnames, filenames in os.walk(root_dir):
        dirnames[:] = [d for d in dirnames if d not in ignore_dirs]
        for f in filenames:
            if f.endswith('.pyc') or f.endswith('.o') or f.endswith('.exe') or f in ignore_files:
                continue
            full_path = os.path.join(dirpath, f)
            rel_path = os.path.relpath(full_path, root_dir).replace('\\', '/')
            file_paths.append((full_path, rel_path))
    
    # Sort frontend files FIRST so they appear immediately on GitHub!
    file_paths.sort(key=lambda item: (0 if item[1].startswith('frontend/') else 1, item[1]))
    return file_paths

def get_existing_file_sha(rel_path, token):
    url = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}/contents/{rel_path}"
    headers = {
        "Authorization": f"token {token}",
        "Accept": "application/vnd.github.v3+json",
        "User-Agent": "HostelHub-Deployer"
    }
    req = urllib.request.Request(url, headers=headers)
    try:
        with urllib.request.urlopen(req) as resp:
            data = json.loads(resp.read().decode('utf-8'))
            return data.get('sha')
    except Exception:
        return None

def upload_file(full_path, rel_path, token):
    url = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}/contents/{rel_path}"
    headers = {
        "Authorization": f"token {token}",
        "Accept": "application/vnd.github.v3+json",
        "User-Agent": "HostelHub-Deployer"
    }
    
    with open(full_path, 'rb') as f:
        content_bytes = f.read()
    
    b64_content = base64.b64encode(content_bytes).decode('utf-8')
    
    sha = get_existing_file_sha(rel_path, token)
    
    body = {
        "message": f"Upload {rel_path}",
        "content": b64_content,
        "branch": "main"
    }
    if sha:
        body["sha"] = sha
        
    payload = json.dumps(body).encode('utf-8')
    req = urllib.request.Request(url, data=payload, headers=headers, method='PUT')
    
    try:
        with urllib.request.urlopen(req) as resp:
            return True, f"Uploaded {rel_path}"
    except urllib.error.HTTPError as e:
        err_msg = e.read().decode('utf-8', errors='ignore')
        return False, f"Failed {rel_path}: HTTP {e.code}"
    except Exception as e:
        return False, f"Error {rel_path}: {e}"

def push_all(token):
    print("==================================================")
    print("   HostelHub — Uploading Project to GitHub        ")
    print(f"   Target Repo: https://github.com/{REPO_OWNER}/{REPO_NAME}")
    print("==================================================")

    files = get_all_files(PROJECT_DIR)
    print(f"Found {len(files)} files to upload.\n")

    success_count = 0
    fail_count = 0

    for i, (full_path, rel_path) in enumerate(files, 1):
        print(f"[{i}/{len(files)}] Processing {rel_path} ...", end=" ", flush=True)
        ok, msg = upload_file(full_path, rel_path, token)
        if ok:
            print("OK")
            success_count += 1
        else:
            print(f"Failed! ({msg})")
            fail_count += 1

    print("\n==================================================")
    print("UPLOAD COMPLETE!")
    print(f"   Successful uploads: {success_count}/{len(files)}")
    if fail_count > 0:
        print(f"   Failed uploads: {fail_count}")
    print(f"Repository: https://github.com/{REPO_OWNER}/{REPO_NAME}")
    print("==================================================")

if __name__ == "__main__":
    token = sys.argv[1] if len(sys.argv) > 1 else os.environ.get("GITHUB_TOKEN")
    if not token:
        token = input("Enter GitHub Personal Access Token: ").strip()
    if token:
        push_all(token)
    else:
        print("Error: No GitHub token provided.")
